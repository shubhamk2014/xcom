import React from 'react'

export default function table() {
  return (
    <div>table</div>
  )
}
