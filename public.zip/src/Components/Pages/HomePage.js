import React from 'react'

function HomePage() {
  return (
    <div className='Homediv'>Welcome</div>
  )
}

export default HomePage